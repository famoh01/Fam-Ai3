// Animation names
#define BLOOD_ANIM_DEFAULT 0
#define BLOOD_ANIM_GROW 1

// Color names

// Patch names

// Names of collision boxes
#define BLOOD_COLLISION_BOX_PART_NAME 0

// Attaching position names

// Sound names
