// Animation names
#define CHERRY03_DEBRIS02_ANIM_DEFAULT 0

// Color names

// Patch names

// Names of collision boxes
#define CHERRY03_DEBRIS02_COLLISION_BOX_PART_NAME 0

// Attaching position names

// Sound names
